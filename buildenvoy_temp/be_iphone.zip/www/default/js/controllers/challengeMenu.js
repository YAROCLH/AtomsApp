
/* JavaScript content from js/controllers/challengeMenu.js in folder common */

/**
 * Variables Declaration
 */

/**
 * Events
 */
        $(document).ready(function(){
            init_challengeMenu();
        });

        /*$(document).on('click', ".BackClickMenu",function(){ 
            SetLastView();
        });
        */
/**
 * Functions
 */
        function init_challengeMenu(){
            challengeMenu_js=true;
        }

        function back_Click(){//Probar si funciona en ios
            SetLastView();
        }
	
