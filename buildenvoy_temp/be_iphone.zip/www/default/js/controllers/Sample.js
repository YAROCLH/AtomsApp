
/* JavaScript content from js/controllers/Sample.js in folder common */

/**
 * Variables Declaration
 */

/**
 * Events
 */
  
/**
 * Functions
 */
	